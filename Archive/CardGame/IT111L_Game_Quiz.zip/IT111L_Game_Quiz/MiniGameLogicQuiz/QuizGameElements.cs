﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using FontGameCollection;
using System.CodeDom;

namespace MiniGameLogicQuiz
{
    internal class QuizGameElements
    {
        public static FontGameCollection.FontGame fontGame = new FontGameCollection.FontGame();


        private QuizGameForm quizGForm;
        public QuizGameElements(QuizGameForm form)
        {
            quizGForm = form;
        }

        public QuizGameElements()
        {

        }


        private static Panel panelForm = new Panel
        {
            Location = new System.Drawing.Point(26, 12),
            Name = "PanelForm",
            Size = new System.Drawing.Size(735, 400),  
            TabIndex = 0,
            //BackColor = Color.LightBlue,
        };

        public static Panel PanelForm
        {
            get { return panelForm; }
            set { panelForm = value; }
        }


        private Label quizMiniTitle = new Label
        {
            Text = "Mini Game Trap: Quiz Blitz",
            Size = new Size(800, 50),
            Font = new Font(fontGame.pfc.Families[1], 28),
            Location = new Point(0, 0),
            ForeColor = Color.Black,
            //BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleCenter,
        };

        public Label QuizMiniTitle
        {
            get { return quizMiniTitle; }
            set { quizMiniTitle = value; }
        }

        private static Label quizQuestion = new Label
        {
            Text = "Question 1",
            Size = new Size(750, 100),
            Font = new Font(fontGame.pfc.Families[0], 20),
            Location = new Point(0, 100),
            ForeColor = Color.Black,
            //BackColor = Color.DarkOliveGreen,
            //BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleCenter,
        };

        public static Label QuizQuestion
        {
            get { return quizQuestion; }
            set { quizQuestion = value; }
        }

        private Button choiceBtnQuiz = new Button
        {
            Text = "Choice 1",
            Size = new Size(160, 80),
            Font = new Font(fontGame.pfc.Families[0], 16),
            Location = new Point(150, 200),
            ForeColor = Color.Black,
            TextAlign = ContentAlignment.MiddleCenter,
        };

        public Button ChoiceBtnQuiz
        {
            get { return choiceBtnQuiz; } 
            set { choiceBtnQuiz = value; }
        }



        public static Button AddChoiceBtnQuiz(string choice)
        {
            Button choiceButton = new Button
            {
                Text = choice,
                Tag = choice,
                Size = new Size(180, 80),
                Font = new Font(fontGame.pfc.Families[0], 16),
                //Location = new Point(150, 200),
                ForeColor = Color.Black,
                TextAlign = ContentAlignment.MiddleCenter,
            };

            return choiceButton;
        }


        public void DisplayQuestion(Object obj)
        {

            if (obj is Button[] buttonArray)
            {
                int x = 150, y = 200;
                int i = 0;
                foreach (Button button in buttonArray)
                {
                    if (i == 2)
                    {
                        y = y + 110;
                        x = 150;
                    }

                    button.Location = new Point(x, y);
                    PanelForm.Controls.Add(button);

                    
                    x += 250; 
                    i++;
                }
            }
        }

    }
}
