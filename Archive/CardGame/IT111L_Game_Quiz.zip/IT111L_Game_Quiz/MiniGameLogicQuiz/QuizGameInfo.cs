﻿using FontGameCollection;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiniGameLogicQuiz
{
    internal class QuizGameInfo
    {

        public static FontGameCollection.FontGame fontGame = new FontGameCollection.FontGame();

        public static int totalTime = 16;
        public static Button[] qChoice;

        public static string[] questions;

        public static ArrayList choiceAL = new ArrayList();
        public static ArrayList questionsAL = new ArrayList();
        public static ArrayList answersAL = new ArrayList();
        public static ArrayList arrRandAL = new ArrayList();

        public static int currScore = 0;
        public static bool isNextLevel = false;


        private static string correctAnswer;

        public static string CorrectAnswer
        {
            get { return correctAnswer; }
            set { correctAnswer = value; }
        }

        public static Label lblTimer = new Label
        {
            Size = new Size(150, 50),
            Font = new Font(fontGame.pfc.Families[0], 25),
            Location = new Point(60, 50),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = Color.Black,
            BackColor = Color.Transparent,
        };

        public static Label LblTimer
        {
            get { return lblTimer; }
            set { lblTimer = value; }
        }

    }
}
