﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace MiniGameLogicQuiz
{
    internal class MiniGameMainTimer : QuizGameInfo
    {
        public System.Windows.Forms.Timer miniGameTick = new System.Windows.Forms.Timer();
        
        public Label time = QuizGameInfo.LblTimer;

        public void CGFormTimerStart()
        {
            miniGameTick.Interval = 1000;
            miniGameTick.Enabled = true;
            miniGameTick.Tick += GameActions;
            miniGameTick.Start();
        }

        public void CGFormTimerStop()
        {
            miniGameTick.Stop();

            QuizGameForm.Instance.CloseForm();
        }

        public void GameFormTimer()
        {
            totalTime--;
            LblTimer.Text = $"Time Left: {totalTime}";
            
        }

        public void GameActions(object sender, EventArgs e)
        {
            GameFormTimer();

            Console.WriteLine($"{currScore} {QuizGameLogic.numQuestion}");
            if (currScore == QuizGameLogic.numQuestion)
            {
                CGFormTimerStop();
            }

            if (totalTime == 0)
            {
                CGFormTimerStop();
            }
        }
    }
}
