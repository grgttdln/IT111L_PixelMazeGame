﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace MiniGameLogicQuiz
{
    internal class QuizGameLogic : QuizGameElements
    {

        MiniGameMainTimer timer = new MiniGameMainTimer();

        public static int numQuestion = 0;

        public void DisplayRandomQuestion(int idx)
        {
            QuizGameElements.QuizQuestion.Text = (string)QuizGameInfo.questionsAL[idx];
            QuizGameInfo.CorrectAnswer = (string)QuizGameInfo.answersAL[idx];
            DisplayQuestion(QuizGameInfo.choiceAL[idx]);
            PanelForm.Controls.Add(QuizGameElements.QuizQuestion);
        }


        public void CheckAnswer(string ans, string correctAns)
        {
            if (ans == correctAns)
            {
                Console.WriteLine("Correct");
                QuizGameInfo.currScore += 1;
                Console.WriteLine(QuizGameInfo.currScore);

                PanelForm.Controls.Clear();

                if (QuizGameInfo.currScore == QuizGameLogic.numQuestion)
                {
                    timer.CGFormTimerStop();
                    return;
                }

                ShuffleQuestionPick();

            }
            else
            {
                Console.WriteLine("Incorrect");
            }
        }


        public void ShuffleQuestionPick()
        {
            Random random = new Random();

            int rIdx = random.Next(0, QuizGameInfo.questionsAL.Count);
            while (QuizGameInfo.arrRandAL.Contains(rIdx))
            {
                rIdx = random.Next(0, QuizGameInfo.questionsAL.Count);
            }
            Console.WriteLine(rIdx);
            QuizGameInfo.arrRandAL.Add(rIdx);
            DisplayRandomQuestion(rIdx);
        }
    

        public void ShuffleAnswerChoices(ref string[] array)
        {
            Random random = new Random();
            ArrayList arrRand = new ArrayList();
            string[] tempArr = new string[4];
            Array.Copy(array, tempArr, 4);

            for (int i = 0; i < 4; i++)
            {
                int rIdx = random.Next(0, 4);
                while (arrRand.Contains(rIdx))
                {
                    rIdx = random.Next(0, 4);
                }
                arrRand.Add(rIdx);

                tempArr[i] = array[rIdx];
            }

            Array.Copy(tempArr, array, 4);
        }


        public void ChoiceAction(object sender, EventArgs e)
        {
            string playerAns = (sender as Button).Text;
            CheckAnswer(playerAns, QuizGameInfo.CorrectAnswer);
        }


        public void LoadQuiz()
        {
            try
            {
                QuizGameInfo.questions = File.ReadAllLines("./data/quiz.txt");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }


            switch (QuizGameForm.currentPlayerLevel)
            {
                case 1:
                    numQuestion = 3;
                    break;
                case 2:
                    numQuestion = 4;
                    break;
                case 3:
                    numQuestion = 5;
                    break;
            }

            for (int i = 0; i < QuizGameInfo.questions.Length; i++)
            {
                QuizGameInfo.qChoice = new Button[4];
                string[] qSplitter = QuizGameInfo.questions[i].Split('|');

                QuizGameInfo.questionsAL.Add(qSplitter[0]);
                QuizGameInfo.answersAL.Add(qSplitter[4]);

                qSplitter = qSplitter.Skip(1).ToArray();
                ShuffleAnswerChoices(ref qSplitter);

                for (int j = 0; j <= 3; j++)
                {
                    QuizGameInfo.qChoice[j] = AddChoiceBtnQuiz(qSplitter[j]);
                    QuizGameInfo.qChoice[j].Click += ChoiceAction;
                }
                QuizGameInfo.choiceAL.Add(QuizGameInfo.qChoice);
            }

        }


    }
}
